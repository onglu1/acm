//
// Created by onglu on 2022/7/23.
//

#include <bits/stdc++.h>
#define int long long
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()

#define endl '\n'
#define lson (rt << 1)
#define rson (rt << 1 | 1)
#define Mid ((l + r) / 2)
//#define int long long
using namespace std;
const int N = 2e6 + 1009;
//const int N = 2e5 + 1009;
//const int N = 5009;
//const int N = 309;
int n, k, x, a[N], b[N], c[N];
int add[3][2] = {
        {0, 0},
        {0, 1},
        {1, 0}
};
int t[N][2];
void work() {
    cin >> n >> k >> x;
    for(int i = 1; i <= n; i++) cin >> a[i];
    for(int i = 1; i <= n; i++) cin >> b[i];
    for(int i = 1; i <= n; i++) {
        if(a[i] == (b[i] + 1) % 3) c[i] = 1;
        else if((a[i] + 1) % 3 == b[i]) c[i] = 2;
        else c[i] = 0;
    }
    if(x > n) {
        int ok = 1;
        for(int i = 1; i <= n; i++) if(c[i] != c[1] || c[i] == 0) ok = 0;
        if(ok) {
            if(k < x) cout << k * add[c[1]][0] << " " << k * add[c[1]][1] << endl;
            else cout << (k + k - x + 1) * add[c[1]][0] << " " << (k + k - x + 1) * add[c[1]][1] << endl;
            return ;
        }
    }
    if(k <= n) {
        int lst = 0, cnt = 0;
        int ans[2] = {0};
        for(int i = 1; i <= k; i++) {
            if(c[i] == lst) cnt += 1;
            else {
                cnt = 1;
                lst = c[i];
            }
            ans[0] += add[lst][0] * (1 + (cnt >= x));
            ans[1] += add[lst][1] * (1 + (cnt >= x));
        }
        cout << ans[0] << " " << ans[1] << endl;
    } else {
        int lst = 0, cnt = 0;
        int ans[2] = {0};
        for(int i = 1; i <= n; i++) {
            if(c[i] == lst) cnt += 1;
            else {
                cnt = 1;
                lst = c[i];
            }
            ans[0] += add[lst][0] * (1 + (cnt >= x));
            ans[1] += add[lst][1] * (1 + (cnt >= x));
        }
        // cout << ans[0] << " " << ans[1] << endl;
        for(int i = 1; i <= n; i++) {
            if(c[i] == lst) cnt += 1;
            else {
                cnt = 1;
                lst = c[i];
            }
            // cout << lst << " " << cnt << " " << add[lst][0] << " " << add[lst][1] << endl;
            t[i][0] = add[lst][0] * (1 + (cnt >= x)) + t[i - 1][0];
            t[i][1] = add[lst][1] * (1 + (cnt >= x)) + t[i - 1][1];
        }
        // cout << t[n][0] << " " << t[n][1] << endl;
        ans[0] += (k - n) / n * t[n][0] + t[k % n][0];
        ans[1] += (k - n) / n * t[n][1] + t[k % n][1];
        cout << ans[0] << " " << ans[1] << endl;
    }
}

signed main() {
#ifdef LOCAL
    freopen("C:\\Users\\onglu\\CLionProjects\\acm\\data.in", "r", stdin);
    freopen("C:\\Users\\onglu\\CLionProjects\\acm\\data.out", "w", stdout);
#endif
    ios::sync_with_stdio(false);
    cin.tie(0);
    int Case = 1;
    // cin >> Case;
    while(Case--) work();
    return 0;
}