//
// Created by onglu on 2022/7/23.
//

#include <bits/stdc++.h>
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()

#define endl '\n'
#define lson (rt << 1)
#define rson (rt << 1 | 1)
#define Mid ((l + r) / 2)
//#define int long long
using namespace std;
const int N = 4e6 + 1009;
//const int N = 2e5 + 1009;
//const int N = 5009;
//const int N = 309;
int n, m, a[N], tree[N * 4];
void update(int rt) {
    tree[rt] = max(tree[lson], tree[rson]);
}
void build(int l, int r, int rt) {
    if(l == r) return (void) (tree[rt] = a[l]);
    build(l, Mid, lson); build(Mid + 1, r, rson);
    update(rt);
}
void modify(int l, int r, int rt, int pos, int y) {
    if(l == r) {
        tree[rt] = y;
        return ;
    }
    if(pos <= Mid) modify(l, Mid, lson, pos, y);
    else modify(Mid + 1, r, rson, pos, y);
    update(rt);
}
int queryR(int l, int r, int rt, int L, int R, int y) {
    if(L > R) return -1;
    // cerr << l << " " << r << " " << L << " " << R << endl;
    if(l == L && r == R) {
        if(tree[rt] < y) return -1;
        else {
            if(l == r) return l;
            if(tree[lson] >= y) return queryR(l, Mid, lson, L, Mid, y);
            else return queryR(Mid + 1, r, rson, Mid + 1, R, y);
        }
    } else {
        if(R <= Mid) return queryR(l, Mid, lson, L, R, y);
        else if(Mid < L) return queryR(Mid + 1, r, rson, L, R, y);
        else {
            int pos = queryR(l, Mid, lson, L, Mid, y);
            if(pos == -1) return queryR(Mid + 1, r, rson, Mid + 1, R, y);
            return pos;
        }
    }
}
int queryL(int l, int r, int rt, int L, int R, int y) {
    if(L > R) return -1;
    if(l == L && r == R) {
        if(tree[rt] < y) return -1;
        else {
            if(l == r) return l;
            if(tree[rson] >= y) return queryL(Mid + 1, r, rson, Mid + 1, R, y);
            else return queryL(l, Mid, lson, L, Mid, y);
        }
    } else {
        if(R <= Mid) return queryL(l, Mid, lson, L, R, y);
        else if(Mid < L) return queryL(Mid + 1, r, rson, L, R, y);
        else {
            int pos = queryL(Mid + 1, r, rson, Mid + 1, R, y);
            if(pos == -1) return queryL(l, Mid, lson, L, Mid, y);
            return pos;
        }
    }
}
int modify(int pos, int y) {
    a[pos] = y;
    modify(1, n, 1, pos, y);
}
void work() {
    cin >> n >> m;
    for(int i = 1; i <= n; i++) cin >> a[i];
    build(1, n, 1);
    for(int i = 1; i <= m; i++) {
        int x, y, L, R;
        cin >> x >> y >> L >> R;
        if(a[x] == y) {
            cout << 0 << endl;
            continue;
        }
        int t = y < a[x] ? a[x] : y;
        int rr = queryR(1, n, 1, x + 1, R, t);
        int ll = queryL(1, n, 1, L, x - 1, t);
        if(rr == -1) rr = R;
        else rr -= 1;
        if(ll == -1) ll = L;
        else ll += 1;
        // cout << ll << " " << rr << endl;
        modify(x, y);
        cout << 1ll * (rr - x + 1) * (x - ll + 1) << endl;
    }
}

signed main() {
#ifdef LOCAL
    freopen("C:\\Users\\onglu\\Desktop\\d\\sample4.in", "r", stdin);
    freopen("C:\\Users\\onglu\\Desktop\\d\\data.out", "w", stdout);
#endif
// #ifdef LOCAL
//     freopen("C:\\Users\\onglu\\CLionProjects\\acm\\data.in", "r", stdin);
//     freopen("C:\\Users\\onglu\\CLionProjects\\acm\\data.out", "w", stdout);
// #endif
    ios::sync_with_stdio(false);
    cin.tie(0);
    int Case = 1;
    // cin >> Case;
    while(Case--) work();
    return 0;
}